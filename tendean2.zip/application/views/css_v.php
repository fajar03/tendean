<!-- bootstrap -->
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

<!-- datepicker -->
<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />

<!-- magnific popup, source for : http://dimsemenov.com/plugins/magnific-popup/documentation.html -->
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/magnific-popup.min.css">

<!-- master -->
<link rel="stylesheet" type="text/css" href="assets/css/master/stylesheets/screen.css">
