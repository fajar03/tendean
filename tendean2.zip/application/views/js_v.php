<!-- jquery -->
<script type="text/javascript" src="assets/js/jquery-3.1.1.min.js"></script>

<!-- datepicker -->
<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>

<!-- bootstrap -->
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>

<!-- fontawesome -->
<script src="https://use.fontawesome.com/ad83571181.js"></script>

<!-- magnific popup, source for : http://dimsemenov.com/plugins/magnific-popup/documentation.html -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>

<!-- js validation -->
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script>

<!-- master -->
<script type="text/javascript" src="assets/js/master.js"></script>