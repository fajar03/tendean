# TENDEAN RESIDENCE #
Adalah perumahan di daerah jakarta selatan

Alamat : Jl.Kapten Tendean(Wolter Monginsidi) 127,Jakarta Selatan-12180

### Configuration ###
* unchanged